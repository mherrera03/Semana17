from django.contrib import admin
from django.urls import path
from appsemana17.views import Lista2, Lista3, Lista4, Lista5

#Enrutamiento para acceder a las views respectivas.
#INICIALMENTE NO LLEVA A NIUNGUNA VIEW, SE TIENE QUE HACER LO SIGUIENTE: 
############
#   ____   #
#   |  |   #
#   |  |   #
# __|  |__ #
# \      / #
#  \    /  # 
#    \/    #
#          #
#↓↓↓↓↓↓↓↓↓↓#
#Se tiene que colocar cualquiera de los endpoints para acceder a la view que se desea.

urlpatterns = [
    path('admin/', admin.site.urls),
    path('carreras/', Lista2),
    path('estudiantes/', Lista3),
    path('profesores/', Lista4),
    path('asignatura/', Lista5),
]