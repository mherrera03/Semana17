from django.db import models

#tabla de carreras
class Carreras(models.Model):
    nombre_carrera = models.CharField(max_length=100)

#tabla de estudiantes
class Estudiantes(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    edad = models.CharField(max_length=100)
    carrera_id = models.CharField(max_length=100)

#tabla de profesores
class Profesores(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)

#tabla de asignaturas
class Asignatura(models.Model):
    nombre_asignatura = models.CharField(max_length=100)
    id_profesor = models.CharField(max_length=100)
    carrera_id = models.CharField(max_length=100)
