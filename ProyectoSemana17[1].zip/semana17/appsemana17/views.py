from django.shortcuts import render
from. models import Carreras, Estudiantes, Profesores, Asignatura

#Renderizado de views que retornan las vistas con sus datos respectivos de los regitros de la BD.
def Lista2(request):
    listado2 = Carreras.objects.all()
    return render(request, "carreras.html",{"carrera":listado2})

def Lista3(request):
    listado3 = Estudiantes.objects.all()
    return render(request, "estudiantes.html",{"estudiante":listado3})

def Lista4(request):
    listado4 = Profesores.objects.all()
    return render(request, "profesores.html",{"profesor":listado4})

def Lista5(request):
    listado5 = Asignatura.objects.all()
    return render(request, "asignatura.html",{"asignatura":listado5})